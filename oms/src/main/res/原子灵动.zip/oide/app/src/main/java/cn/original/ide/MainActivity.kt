package cn.original.ide

import oms.ability.视窗能力
import oms.content.意图


class MainActivity : 视窗能力() {


    override fun 当视窗载入时(intent: 意图?) {
        super.当视窗载入时(intent)
        setContentView(R.layout.activity_main)
        // Example of a call to a native method

    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    external fun stringFromJNI(): String

    companion object {
        // Used to load the 'native-lib' library on application startup.
        init {
            System.loadLibrary("native-lib")
        }
    }


}