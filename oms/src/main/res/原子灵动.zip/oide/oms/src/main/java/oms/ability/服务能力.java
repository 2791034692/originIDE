package oms.ability;

public class 服务能力 extends ServiceAbility {

}
