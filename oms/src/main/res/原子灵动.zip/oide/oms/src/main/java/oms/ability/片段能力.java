package oms.ability;

public class 片段能力 extends FragmentAbility {
    public 视窗能力 取视窗(){
        return (视窗能力)getAbility();
    }
}
